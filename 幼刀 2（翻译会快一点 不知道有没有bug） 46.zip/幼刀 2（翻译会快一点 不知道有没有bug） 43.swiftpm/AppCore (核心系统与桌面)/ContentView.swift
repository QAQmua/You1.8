// 📄 替换文件：AppCore (核心系统与桌面)/ContentView.swift
import SwiftUI

// MARK: - 全局根入口
struct ContentView: View {
    @State private var isUnlocked = false
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var lang = LanguageManager.shared
    
    var body: some View {
        ZStack {
            // 🌟 更改了系统级托底背景色为白色
            Color.white.ignoresSafeArea()
            
            if isUnlocked {
                HomeScreenView(isUnlocked: $isUnlocked)
                    .transition(.opacity)
            } else {
                LockScreenView(isUnlocked: $isUnlocked)
                    .transition(.opacity)
            }
        }
    }
}
