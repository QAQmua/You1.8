// 📄 文件：IScreenViewModel.swift
import SwiftUI

class IScreenViewModel: ObservableObject {
    // 导航与搜索状态
    @Published var currentTab: Int = 0
    @Published var isSearching: Bool = false
    @Published var searchText: String = ""
    @Published var searchHistory: [String] = ["ins发布页", "寄语卡片", "对话框", "卡片", "极简翻页钟", "拍立得", "仪表盘电量"]
    
    // 首页筛选状态
    @Published var selectedCategoryFilter: String = "全部"
    let categoryFilters = ["全部", "2×2", "4×2", "4×4"]
    
    // 搜索预设数据
    let allPresets = [
        (title: "ins发布页", category: "社交", icon: "paperplane.fill", color: Color.purple),
        (title: "寄语卡片", category: "便签", icon: "envelope.fill", color: Color.pink),
        (title: "对话框", category: "挂件", icon: "bubble.left.and.bubble.right.fill", color: Color.blue),
        (title: "卡片", category: "照片", icon: "photo.on.rectangle.angled", color: Color.blue),
        (title: "极简翻页钟", category: "时钟", icon: "clock.fill", color: Color.indigo),
        (title: "时光拍立得", category: "照片", icon: "photo.fill", color: Color.teal),
        (title: "每日便签条", category: "便签", icon: "note.text", color: Color.orange),
        (title: "仪表盘电量", category: "系统", icon: "bolt.batteryblock.fill", color: Color.green)
    ]
    
    // 编辑组件的状态
    @Published var activeEditWidgetID: String? = nil
    
    // 🌟 用户个人资料与头像持久化
    private let avatarKey = "App_IScreen_UserAvatar_ImageData"
    @Published var userAvatarData: Data? {
        didSet {
            if let data = userAvatarData {
                UserDefaults.standard.set(data, forKey: avatarKey)
            } else {
                UserDefaults.standard.removeObject(forKey: avatarKey)
            }
        }
    }
    
    @Published var isEditingProfile: Bool = false
    @Published var userName: String = "极客探索者"
    @Published var userBio: String = "记录生活，探索桌面灵感 ✨"
    @Published var userUID: String = "89757"
    
    init() {
        self.userAvatarData = UserDefaults.standard.data(forKey: avatarKey)
    }
}
